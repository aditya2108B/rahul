import { createSlice } from '@reduxjs/toolkit'

const initialState = { 
  personalData: []
}

export const counterSlice = createSlice({
  name: 'personalData',
  initialState,
  reducers: {
    replacepersonalData: (state, action) => {
      state.personalData=action.payload;
     
    },
  },
})

export const {  replacepersonalData} = counterSlice.actions

export default counterSlice.reducer;
