import { createSlice } from '@reduxjs/toolkit'

const initialState = { 
  notifications: null,
}

export const counterSlice = createSlice({
  name: 'counter',
  initialState,
  reducers: {
    addNotification: (state, action) => {
      state.notifications=action.payload;
    },
    clearNotifications: (state) => {
      state.notifications = [];
    }
  },
})

export const { addNotification, clearNotifications } = counterSlice.actions

export default counterSlice.reducer;
