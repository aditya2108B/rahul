import { createSlice } from '@reduxjs/toolkit'
// import AddComponents from '../pages/adminPages/AddComponents';

const initialState = { 
  AllComponents: []
}

export const counterSlice = createSlice({
  name: 'components',
  initialState,
  reducers: {
    ReplaceComponents: (state, action) => {
      state.AllComponents=action.payload;
     
    },

    pushComponents: (state, action) => {
      state.AllComponents.push(action.payload);
    },
  },
})

export const {  ReplaceComponents,pushComponents} = counterSlice.actions

export default counterSlice.reducer;
