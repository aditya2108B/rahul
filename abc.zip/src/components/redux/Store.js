import { configureStore } from '@reduxjs/toolkit'
import counterReducer from './counterSlice.js'
import counterReducer2 from './counterSlice2.js'
import counterReducer3 from './personalData.js'

export const store = configureStore({
  reducer: {
    counter: counterReducer, // For notifications
    components: counterReducer2, 
    personalData:counterReducer3,
  },
});
