import React, { useState, useEffect, useRef } from 'react';
import Cmsnav from './cmsnav';
import { useNavigate } from 'react-router-dom';

const VerifyOTP = () => {
  const navigate = useNavigate(); 
  const [errorMessage, setErrorMessage] = useState(""); // Holds the error message
  const [firstData, setFirstData] = useState({ emailMobile: "" }); // Holds the form data
  const emailMobile = useRef(); // Reference for the input field

  useEffect(() => {
    // Side effects can be handled here if needed
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const inputValue = emailMobile.current.value.trim();
    
    if (inputValue.length !== 6 || !/^\d+$/.test(inputValue)) {
      setErrorMessage("Please enter a valid 6-digit OTP.");
      return;
    }

    setErrorMessage(""); // Clear previous errors
    setFirstData({ emailMobile: inputValue });
    
    try {
      await forgotPass({ emailMobile: inputValue });
    } catch (error) {
      setErrorMessage("Failed to verify OTP. Please try again.");
    }

    emailMobile.current.value = ''; // Clear input field after submission
  };

  const handleChange = (e) => {
    setFirstData({ ...firstData, [e.target.name]: e.target.value });
  };

  const forgotPass = async (email) => {
    try {
      const response = await fetch('http://localhost:8000/checkotp', {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(email),  
      });
    //  if(response
    //   .status(200)
    //  ){
    //     navigate('/resetPassword')
    //  }
      const data = await response.json();
      console.log(data)
      if (data.message=='OTP is correct'){
        navigate('/resetpass')
      }else{
        setErrorMessage(" OTP is incorrect. Please try again.");
      }
      
    } catch (error) {
      console.error("Error sending OTP:", error);
      throw error; // Pass error for handling in handleSubmit
    }
  };

  return (
    <>
      <Cmsnav />
      <div className="body">
        <div className="box">
          <div className="container2">
            <div className="top-header">
              <header>Log In</header>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="input-field">
                <input
                  ref={emailMobile}
                  onChange={handleChange}
                  type="text"
                  inputMode="numeric"
                  className="input"
                  name="emailMobile"
                  placeholder="Enter OTP"
                  maxLength={6}
                  required
                />
                <i className="fas fa-envelope icon" />
              </div>

              {/* Display the error message if it exists */}
              {errorMessage && (
                <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
                  {errorMessage}
                </div>
              )}

              <div className="input-field input-field2">
                <input type="submit" className="submit" value="Check" />
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default VerifyOTP;
