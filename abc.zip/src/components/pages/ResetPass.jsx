import React, { useEffect, useRef, useState } from 'react';
import '../css/Signup.css';
import { Link } from 'react-router-dom';
import Cmsnav from './cmsnav';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

const Signup = () => {
  const navigate = useNavigate();
  
  const fetchEmail = async () => {
    const token = Cookies.get("email");
    if (!token) {
      navigate('/forgotpass');
      
    } 
    // remove cookie named email
  


  };
  const fetchToken = async () => {
    const token = Cookies.get("token");
    const token2=Cookies.get("admin")
    if (token||token2) {
      Cookies.remove("email");
      navigate('/');
      console.log("Token exists:", token);
    } else {
      console.log("No token found");
    }
  }

  useEffect(() => {
    fetchEmail();
    fetchToken();
  }, []);

  const password = useRef();
  const confirmPass = useRef();
  const username = useRef();  // New ref for username

  const [data, setData] = useState({});

  const sendData = () => {
    // Add both password and username to the data object before sending
    const updatedData = { ...data, password: password.current.value, username: username.current.value };

    fetch('http://localhost:8000/resetpass', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updatedData), // Send the updated data object
    })
      .then((response) => response.json())
      .then((data) => {
        fetchToken();
        console.log('Success:', data);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const handleChange = (e) => {
    if (e.target.name !== 'confirmPass') {
      setData({ ...data, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password.current.value === confirmPass.current.value) {
      sendData();
      password.current.value = "";
      confirmPass.current.value = "";
      username.current.value = "";  // Clear the username
    } else {
      alert('Password and confirm password do not match');
    }
  };

  return (
    <>
      <Cmsnav />
      <div className="body">
        <div className="box">
          <div className="container">
            <div className="top-header">
              <header>Reset Password</header>
            </div>
            <form onSubmit={handleSubmit}>
              {/* Optionally hidden username field for accessibility */}
              <div className="input-field visually-hidden">
                <label htmlFor="username" className="visually-hidden">Username</label>
                <input
                  ref={username}
                  name="username"
                  type="text"
                  id="username"
                  className="input"
                  placeholder="  Username"
                  onChange={handleChange}
                  autoComplete="username"
                  aria-hidden="false"
                  style={{ position: 'absolute', opacity: 0, height: '1px', width: '1px', overflow: 'hidden' }}
                />
              </div>
              <div className="input-field">
                <input
                  ref={password}
                  name="password"
                  type="password"
                  className="input"
                  placeholder="  Password"
                  required
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <i className="fas fa-lock icon" />
              </div>
              <div className="input-field">
                <input
                  ref={confirmPass}
                  name="confirmPass"
                  type="password"
                  className="input"
                  placeholder="  Confirm Password"
                  required
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <i className="fas fa-lock icon" />
              </div>
              <div className="input-field input-field2">
                <input type="submit" className="submit" value="Change Password" />
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Signup;
