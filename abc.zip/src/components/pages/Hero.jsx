import React, { useRef, useState } from "react";
import { Link } from "react-router-dom";
import "../css/Hero.css";
import frameImage from "../img/Frame2.webp";
import Cmsnav from "./cmsnav";
import Cards from "./Cards";
import Footer from "./Footer";

export default function Hero() {
  const bottom = useRef();

  const herostyle = {
    backgroundImage: `url(${frameImage})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    height: "100vh",
  };

 

  return (
    <>
      <div className="whole">
        <Cmsnav bottom={bottom} />
        <div className="hero" style={herostyle}>
          <div className="container">
            <div className="heading">Access All Your Components</div>
            <div className="buttons">
              <div className="explore">
                <button>
                  <a href="/#" target="_blank">
                    Explore Lab
                  </a>
                </button>
              </div>
              <div className="Sign-In">
                <button>
                  <Link className="Link" to="/components">
                    Components
                  </Link>
                </button>
              </div>
            </div>
            <div className="info">
              Our Component Management System simplifies the process of
              tracking, organizing, and maintaining your components. Whether
              you're dealing with hardware parts, software modules, or any
              other resources, our system provides a platform to manage your
              inventory and ensure you always have the components you need.
            </div>
          </div>
        </div>
        {/* <Cards  /> */}
        {/* <div ref={bottom}>
          <Footer />
        </div> */}
      </div>
    </>
  );
}
