import React, { useRef, useState, useEffect } from "react";
import "../css/Login.css";
import { Link, useNavigate ,useSearchParams} from "react-router-dom";
import Cmsnav from "./cmsnav";
import Cookies from "js-cookie";

const Login = () => {
const [searchParams]=useSearchParams();
  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");  // State to hold the error message

  const redirectTo = searchParams.get("redirect") || "/";
console.log(redirectTo)
  const fetchToken = async () => {
    const token = Cookies.get("token");
    const admin = Cookies.get("admin");
  
    if (token || admin) {
      console.log(redirectTo)
      navigate(redirectTo);
      console.log("Token exists:", token);
      if (admin) {
        console.log("Admin cookie exists:", admin);
      }
    } else {
      console.log("No token or admin cookie found");
    }
  };
  

  useEffect(() => {
    fetchToken();
  }, []);

  const emailMobile = useRef();
  const password = useRef();
  const [validateData, setValidateData] = useState([]);
  const [firstData, setfirstData] = useState([]);

  const sendData = (data) => {
    console.log(data);
    fetch('http://localhost:8000/login', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then(async (response) => {
        const result = await response.json();  // Parse the response to get the result

        if (response.status === 404) {  // Assuming 404 means user not found
          setErrorMessage("User not found. Please check your email/mobile or password.");
        } else if (response.status === 200) { 
          setErrorMessage("");  
          fetchToken();  
          console.log('Success:', result);
        }
      })
      .catch((error) => {
        console.error('Error:', error);
        setErrorMessage("An error occurred. Please try again later.");  // Show a generic error message
      });
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = checkIfEmailOrMobile(emailMobile.current.value);
    if (name !== "you enter wrong things") {
      setValidateData({
        ...validateData,
        [name]: firstData.emailMobile,
        password: firstData.password,
      });
      sendData({
        ...validateData,
        [name]: firstData.emailMobile,
        password: firstData.password,
      });
    } else {
      setErrorMessage("Please enter a valid email or mobile number.");
    }

    emailMobile.current.value = '';
    password.current.value = '';
  };

  const checkIfEmailOrMobile = (item) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobilePattern = /^\d{10}$/;
    if (emailPattern.test(item)) {
      return "email";
    } else if (mobilePattern.test(item)) {
      return "number";
    } else {
      return "you enter wrong things";
    }
  };

  const handleChange = (e) => {
    setfirstData({ ...firstData, [e.target.name]: e.target.value });
  };

  console.log(firstData);

const forgotPassword=async()=>{
navigate('/forgotpass')
}

  return (
    <>
      <Cmsnav />
      <div className="body">
        <div className="box">
          <div className="container2">
            <div className="top-header">
              <header>Log In</header>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="input-field">
                <input
                  ref={emailMobile}
                  onChange={handleChange}
                  type="text"
                  className="input"
                  name="emailMobile"
                  placeholder=" Email/Mobile Number"
                  autoComplete="email"
                  required
                />
                <i className="fas fa-envelope icon" />
              </div>
              <div className="input-field">
                <input
                  ref={password}
                  onChange={handleChange}
                  type="password"
                  name="password"
                  className="input"
                  placeholder="Password"
                  autoComplete="current-password"
                  required
                />
                <i className="fas fa-lock icon" />
              </div>
              <div className="right">
                <label>
                  <div  onClick={forgotPassword}>Forgot password?</div>
                </label>
              </div>

              {/* Display the error message if it exists */}
              {errorMessage && (
                <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
                  {errorMessage}
                </div>
              )}

              <div className="input-field input-field2">
                <input type="submit" className="submit" value="Login" />
                <div className="signup-link">
                  <p>
                    Don't have an account? <Link to="/signup">Sign Up</Link>
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
