import React, { useState, useRef, useEffect } from "react";
import "../css/cards.css";
import Cmsnav from "./cmsnav";
import Footer from "./Footer";
import { ReplaceComponents } from "../redux/counterSlice2";
import { useDispatch } from "react-redux";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSearchParams } from "react-router-dom";
import { Oval } from 'react-loader-spinner';

const AfterSearchPage = () => {
  const bottom = useRef();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // const [k, setk] = useState(second)

  const [boxes, setBoxes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [search, setsearch] = useState("");
  const [recommendComponentsState, setrecommendComponentsState] = useState([]);
  const [filteredBoxes, setfilteredBoxes] = useState([]);
  const [categoryList, setcategoryList] = useState([]);
  const [realBoxes, setrealBoxes] = useState([]);
  const [allCompo, setallCompo] = useState([]);
  const [searchingornot, setsearchingornot] = useState(false);
  const [loading, setloading] = useState(true);

  const fetchComponents = async () => {
    try {
      const response = await axios.get("http://localhost:8000/getcomponents", {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log(response.data);
      dispatch(ReplaceComponents(response.data[0]));
      setBoxes([...response.data[0]]);
      setcategoryList(response.data[1]);
      setrealBoxes([...response.data[0]]);
      setallCompo([...response.data[2]]);
      setTimeout(() => {
        setloading(false)
        
      }, 50);
    } catch (error) {
      console.error("Error fetching components:", error);
    }
  };
  const keyword = searchParams.get("k");

  useEffect(() => {
    if (keyword && allCompo.length > 0) {
      setSearchTerm(keyword);
      setsearchingornot(true);

      const searchedData = allCompo.filter((item) => {
        return (
          item.componentName.toLowerCase().includes(keyword.toLowerCase()) ||
          item.componentCategory.toLowerCase().includes(keyword.toLowerCase())
        );
      });

      setBoxes(searchedData);
    }
    else{
      setsearchingornot(false);
      setSearchTerm("");
      setBoxes([...realBoxes]);
    }
  }, [keyword,allCompo]);

  useEffect(() => {
    fetchComponents();
  }, []);

if(loading){
  return<div>
  <Oval
    height={80}
    width={80}
    color="blue"
    ariaLabel="loading"
  />
</div>
}

  const handleKeyPress = async (event) => {
    if (event.key === "Enter") {
      console.log("Enter key was pressed");

      if (searchTerm === "") {
        setsearchingornot(false);
        setfilteredBoxes([]);
        setBoxes([...realBoxes]);
        navigate(`/components`);
      } else {
        setsearch(searchTerm);
        setsearchingornot(true);
        const searchedData = allCompo.filter((item) => {
          return (
            item.componentName
              .toLowerCase()
              .includes(searchTerm.toLowerCase()) ||
            item.componentCategory
              .toLowerCase()
              .includes(searchTerm.toLowerCase())
          );
        });

        console.log(searchedData);
        setBoxes([...searchedData]);
        navigate(`/components?k=${searchTerm}`);
      }
     
    }
  };

  // const recommendComponents = async (str) => {
  //   const filteredBoxes2 = realBoxes.filter((item) =>
  //     item.componentName.toLowerCase().includes(str.toLowerCase())
  //   );
  //   if (filteredBoxes2.length > 0) {
  //     const recommend = boxes.filter(
  //       (item) =>
  //         item.componentCategory === filteredBoxes2[0].componentCategory &&
  //         item.componentName !== filteredBoxes2[0].componentName
  //     );
  //     console.log(recommend);
  //     setrecommendComponentsState([...recommend]);
  //   }
  // };
  console.log(filteredBoxes);
  return (
    <div className="after-search-page">
      <Cmsnav bottom={bottom} />

      <div className="search-bar">
        <input
          type="text"
          placeholder="Search components..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
          }}
          onKeyDown={handleKeyPress}
          className="search-input"
        />
      </div>

      <div
        className={searchingornot ? "categoriesCard" : "component-container"}
      >
        {boxes &&
          boxes.length > 0 &&
          boxes.map((item) => {
            return (
              <div className={searchingornot ? "" : "component-categorised"}>
                <h1>{item[0]?.componentCategory}</h1>

                <div className={searchingornot ? "" : "categoriesCard"}>
                  {item.length > 0 ? (
                    item.map((i) => {
                      console.log("object", i);
                      return (
                        <div key={i._id} className="component-card2">
                          <div className="component-content">
                            {i.componentImage && (
                              <img
                                src={i.componentImage}
                                alt={i.componentName}
                                className="component-image"
                              />
                            )}
                            <div className="component-title">
                              {i.componentName}
                            </div>

                            <div className="component-availability">
                              Availability: {i.numberOfComponents}
                            </div>
                            <button
                              onClick={(e) => {
                                e.preventDefault();
                                navigate(`/components/${i._id}`);
                              }}
                            >
                              Issue
                            </button>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div key={item._id} className="component-card2">
                      <div className="component-content">
                        {item.componentImage && (
                          <img
                            src={item.componentImage}
                            alt={item.componentName}
                            className="component-image"
                          />
                        )}
                        <div className="component-title">
                          {item.componentName}
                        </div>

                        <div className="component-availability">
                          Availability: {item.numberOfComponents}
                        </div>
                        <button
                          onClick={(e) => {
                            e.preventDefault();
                            navigate(`/components/${item._id}`);
                          }}
                        >
                          Issue
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
      </div>

      <div ref={bottom}>
        <Footer />
      </div>
    </div>
  );
};

export default AfterSearchPage;
