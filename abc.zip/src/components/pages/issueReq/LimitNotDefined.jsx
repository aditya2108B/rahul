import React from 'react';
import { useNavigate } from 'react-router-dom'; 

const LimitNotDefined = () => {
  const navigate = useNavigate();

  const handleOkClick = () => {
    navigate('/components');
  };

  return (
    <div style={styles.overlay}>
      <div style={styles.card}>
        <h2 style={styles.message}>You Set Quantity which is not good!</h2>
        <button style={styles.button} onClick={handleOkClick}>OK</button>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    width: '100vw',
    position: 'fixed',
    top: 0,
    left: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
    backdropFilter: 'blur(10px)', // Blur effect for the background
    zIndex: '1000',
  },
  card: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '300px',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#fff',
  },
  message: {
    marginBottom: '20px',
    textAlign: 'center',
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default LimitNotDefined;
