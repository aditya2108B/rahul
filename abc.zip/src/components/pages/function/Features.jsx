import Cookies from "js-cookie";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { addNotification } from "../../redux/counterSlice";
import { ReplaceComponents } from "../../redux/counterSlice2";

export const fetchPersonalData = async (token_str) => {
  console.log("Fetching personal data...");
  
  const token = Cookies.get(token_str);
  console.log(token)
  if (token) {
    try {
      const response = await axios.get("http://localhost:8000/getpersonaldata", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Check if the response contains the image URL
      if (response && response.data ) {
        const imageUrl = response.data;
        console.log("Image URL:", imageUrl);
        return imageUrl;  
      } else {
        throw new Error("Image URL not found in the response.");
      }
    } catch (error) {
      console.log("Error:", error.message);
    }
  } else {
    console.log("No token found.");
  }
};




export const handleSubmit = async (file, token) => {
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);
  formData.append("token", token);

  try {
    const response = await axios.post(
      "http://localhost:8000/personaldata",
      formData,
      {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      }
    );
    console.log("File uploaded successfully:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error uploading file:", error);
  }
};

export const checkItlogInorNot = (token_str, navigate) => {
  const token = Cookies.get(token_str);
  console.log(token)
  if (!token) {
    navigate("/login");
  }
};

export const handleNameChange = async (name, token) => {
  console.log("bhai");
  const cookie = Cookies.get(token);
  if (cookie) {
    try {
      const response = await axios.post(
        "http://localhost:8000/changename",
        {
          name,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );
      return response.data;
    } catch (error) {
      console.error("Error changing name:", error);
    }
  }
};


export const UserListforAdmin = async (dispatch) => {
  try {
    
    const response = await axios.get("http://localhost:8000/allinfo", {
      headers: { Authorization: `Bearer ${Cookies.get("admin")}` },
    });

    const { data } = response;

    dispatch(addNotification(data.notification2)); 
    dispatch(ReplaceComponents(data.allComponent));

  } catch (error) {
    console.error("Error fetching data: ", error);
  }
};

export const fetchComponents = async (dispatch) => {
  try {
    const response = await axios.get("http://localhost:8000/getcomponents", {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log(response.data);
    dispatch(ReplaceComponents(response.data[0]));
    console.log(response.data[2])
   
  } catch (error) {
    console.error("Error fetching components:", error);
  }
};