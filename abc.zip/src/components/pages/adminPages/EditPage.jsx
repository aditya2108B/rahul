import React, { useEffect, useState } from "react";
import { useSelector ,useDispatch} from "react-redux";
import { handleSubmit,handleNameChange } from "../function/Features";
import Cookies from "js-cookie";
import { replacepersonalData } from "../../redux/personalData";

const EditPage = () => {
  // States

  const personalData = useSelector((state) => state.personalData);
  console.log(personalData.personalData.name);

  const dispatch=useDispatch();

useEffect(() => {
  setName(personalData.personalData.name)
}, [personalData.personalData.name])


  const [profileImg, setProfileImg] = useState(null); 
  const [isEditing, setIsEditing] = useState(false);  
  const [name, setName] = useState(); 

console.log(name)
  // Handle image selection
  const handleProfileImgChange = async(e) => {
    const admin=Cookies.get("admin")  
    const file = e.target.files[0];
    if (file) {
      const saveProfileImg=await handleSubmit(file, admin);
      console.log(saveProfileImg)
      dispatch(replacepersonalData(saveProfileImg))
    }
  };

  
  const onChangeNameClick = async(e) => {
    e.preventDefault();
    const admin=Cookies.get("admin") 
    const changeName=await handleNameChange(name, "admin");
    dispatch(replacepersonalData(changeName))
    setIsEditing(false); 
  };

  return (
    <div>
      <div className="profile-section">
        {/* Profile Picture */}
        <div
          className="profile-picture"
          onClick={() => document.getElementById("profileImg").click()}
        >
          {personalData.personalData.profileImg ? (
            <img src={personalData.personalData.profileImg} alt="Profile" />
          ) : personalData && personalData.personalData.profileImg ? (
            <img src={personalData.personalData.profileImg} alt="Profile" />
          ) : (
            <span className="plus-sign">+</span>
          )}
        </div>

        <input
          type="file"
          id="profileImg"
          accept="image/*"
          style={{ display: "none" }}
          onChange={handleProfileImgChange} 
        />

        {/* Name Section */}
        <div className="admin-name-section">
          {isEditing ? (
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="name-input"
            />
          ) : (
            <p className="admin-name">{name || personalData.personalData.name}</p> 
          )}
        </div>

        {/* Edit Buttons */}
        <div className="edit-buttons">
          {isEditing ? (
            <button onClick={onChangeNameClick} className="save-btn">
              Save Name
            </button>
          ) : (
            <button
              onClick={(e) => {
                e.preventDefault();
                setIsEditing(true);
              }}
              className="edit-btn"
            >
              Edit Name
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EditPage;
