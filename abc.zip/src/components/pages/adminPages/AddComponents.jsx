import React, { useState } from 'react';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { ReplaceComponents } from '../../redux/counterSlice2';

const AddComponents = () => {
  const [formData, setFormData] = useState({
    componentName: '',
    componentDescription: '',
    numberOfComponents: '',
    componentImage: null,
    componentCategory: '', // New field for component category
  });
  
const dispatch = useDispatch();

  const [isSubmitting, setIsSubmitting] = useState(false); // For disabling button after submission

  const handleChange = (e) => {
    const { name, value, type, files } = e.target;
    if (type === 'file') {
      setFormData({
        ...formData,
        [name]: files[0],
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Disable submit button
    setIsSubmitting(true);
   
    try {
      const response = await axios.post("http://localhost:8000/addComponent", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        withCredentials: true,
      });
     dispatch(ReplaceComponents(response.data.categorisedcomponents));
      setFormData({
        componentName: '',
        componentDescription: '',
        numberOfComponents: '',
        componentImage: null,
        componentCategory: '',
      });
   
      setTimeout(() => {
        setIsSubmitting(false);
      }, 3000);

    } catch (error) {
      console.error("Error uploading file:", error);
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{ margin: '20px', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h2>Manage Components</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <label>Component Name:</label>
          <input
            type="text"
            name="componentName"
            value={formData.componentName}
            onChange={handleChange}
            placeholder="Enter component name"
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Component Description:</label>
          <textarea
            name="componentDescription"
            value={formData.componentDescription}
            onChange={handleChange}
            placeholder="Enter description (1-2 lines)"
            rows="3"
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>No. of Components:</label>
          <input
            type="number"
            name="numberOfComponents"
            value={formData.numberOfComponents}
            onChange={handleChange}
            placeholder="Enter number of components"
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Component Image:</label>
          <input
            type="file"
            name="componentImage"
            accept="image/*"
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          />
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Component Category:</label>
          <select
            name="componentCategory"
            value={formData.componentCategory}
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '8px', marginTop: '5px' }}
          >
            <option value="">Select a category</option>
            <option value="Microcontroller">Microcontroller</option>
            <option value="Microprocessor">Microprocessor</option>
            <option value="Chasis">Chasis</option>
            <option value="Wheels">Wheels</option>
            <option value="Motors">Motors</option>
            <option value="Motor Driver">Motor Driver</option>
          </select>
        </div>

        <button 
          type="submit" 
          disabled={isSubmitting} 
          style={{ padding: '10px 20px', backgroundColor: '#28a745', color: '#fff', border: 'none', borderRadius: '5px', cursor: isSubmitting ? 'not-allowed' : 'pointer' }}
        >
          {isSubmitting ? "Submitting..." : "Submit"}
        </button>
      </form>
    </div>
  );
};

export default AddComponents;
