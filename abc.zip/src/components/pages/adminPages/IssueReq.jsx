import React, { useState, useEffect } from 'react';
import axios from 'axios';

const IssueReq = () => {
  const [issueRequests, setIssueRequests] = useState([]);

  // Fetch issue requests on component mount
  useEffect(() => {
    const fetchIssueReq = async () => {
      try {
        const response = await axios.get(`http://localhost:8000/sendingIssueReq`, {
          withCredentials: true, // Include credentials (e.g., cookies)
        });
        setIssueRequests(response.data); // Assuming the backend sends an array of requests
      } catch (error) {
        console.log('Error fetching issue requests:', error);
      }
    };

    fetchIssueReq();
  }, []);

  // Handle accept or reject
  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const response = await axios.post(
        `http://localhost:8000/issueReqAcceptorReject`, // Assuming this is the update endpoint
        { id: id, status: newStatus }, // Send request _id and the new status
        {
          withCredentials: true, // Send credentials to allow authenticated request
        }
      );
      if (response.status === 200) {
        // Update local state to reflect status change
        setIssueRequests((prevRequests) =>
          prevRequests.map((req) =>
            req._id === id ? { ...req, status: newStatus } : req
          )
        );
      }
    } catch (error) {
      console.log('Error updating issue request status:', error);
    }
  };

  return (
    <div>
      <div className="content-section">
        <h2>Issue Requests</h2>
        {issueRequests.length > 0 ? (
          issueRequests.map((request) => (
            <div key={request._id} className="request-card">
              <p><strong>User Email:</strong> {request.user_email}</p>
              <p><strong>Component ID:</strong> {request.component_id}</p>
              <p><strong>Quantity:</strong> {request.quantity}</p>
              <p><strong>Status:</strong> {request.status}</p>
              
              {request.status === 'pending' && (
                <div>
                  <button
                    onClick={() => handleUpdateStatus(request._id, 'accepted')}
                    className="accept-btn"
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(request._id, 'rejected')}
                    className="reject-btn"
                  >
                    Reject
                  </button>
                </div>
              )}
            </div>
          ))
        ) : (
          <p>No pending requests.</p>
        )}
      </div>
    </div>
  );
};

export default IssueReq;
