import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import axios from "axios";
import { ReplaceComponents } from "../../redux/counterSlice2";
import { fetchComponents } from "../function/Features";

const AllComponentList = () => {
  const reduxComponents = useSelector((state) => state.components);
  const component = reduxComponents.AllComponents;

  const [components, setcomponents] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [editState, setEditState] = useState(false);
  const [objectforediting, setobjectforediting] = useState(null);
  const [editedValues, setEditedValues] = useState({});

  const dispatch = useDispatch();

  // Fetch components or use Redux data
  useEffect(() => {
    if (component.length > 0) {
      setcomponents(component);
    } else {
      fetchComponents(dispatch);
    }
  }, [reduxComponents, component, dispatch]);

  // Debug log for components
  useEffect(() => {
    console.log("Components updated:", components);
  }, [components]);

  // Handle input changes for editing form
  const handleInputChange = (id, field, value) => {
    setEditedValues((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        [field]: value,
      },
    }));
  };

  // Enable edit mode and populate editing state
  const toggleEditMode = (id) => {
    
    setEditState(true);
    setEditingId(id);

    const flatComponents = components.flat();
    const editingItem = flatComponents.find((item) => item._id === id);
    if (editingItem) {
      setobjectforediting(editingItem);
    } else {
      console.error("Item not found for editing:", id);
    }
  };

  // Close edit form
  const closeEditForm = () => {
    setEditState(false);
    setEditingId(null);
  };

  // Save changes and update Redux store
  const saveChanges = async () => {
    const formData = new FormData();
    const editedItem = editedValues[editingId];

    formData.append("id", editingId);
    if (editedItem?.componentName)
      formData.append("componentName", editedItem.componentName);
    if (editedItem?.componentDescription)
      formData.append("componentDescription", editedItem.componentDescription);
    if (editedItem?.numberOfComponents)
      formData.append("numberOfComponents", editedItem.numberOfComponents);
    if (editedItem?.componentCategory)
      formData.append("componentCategory", editedItem.componentCategory);
    if (editedItem?.componentImage)
      formData.append("componentImage", editedItem.componentImage);

    const response = await axios.post(
      `http://localhost:8000/changeComponentsData`,
      formData,
      {
        headers: { "Content-Type": "multipart/form-data" },
        withCredentials: true,
      }
    );

    dispatch(ReplaceComponents(response.data.categorisedcomponents));
    closeEditForm();
  };

  // Delete a component and update Redux store
  const deleteCard = async (id) => {
    const response = await axios.post(
      `http://localhost:8000/deleteComponent`,
      { id },
      {
        headers: { "Content-Type": "application/json" },
        withCredentials: true,
      }
    );

    dispatch(ReplaceComponents(response.data.categorisedcomponents));
  };

console.log(editingId, editState, objectforediting);

  return (
    <div>
      <div className="component-list-container">
        {components.map((data) => (
          <div key={data[0]?._id || Math.random()} className="categorised_main">
            <h1>{data[0]?.componentCategory}</h1>
            <div className="categorised">
              {data.map((item) => (
                <div key={item._id} className="component-card">
                  <div className="component-content">
                    {item.componentImage && (
                      <img
                        src={item.componentImage}
                        alt={item.componentName}
                        className="component-image"
                      />
                    )}
                    <div className="component-title">{item.componentName}</div>
                    <div className="component-availability">
                      Availability: {item.numberOfComponents}
                    </div>
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                        toggleEditMode(item._id);
                      }}
                      className="btn-edit"
                    >
                      Edit
                    </button>
                    <button
                      className="btn-delete"
                      onClick={(e) => {
                        e.preventDefault();
                        deleteCard(item._id);
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {editingId && editState &&  (
          <div className="edit-form">
            <button className="close-button" onClick={closeEditForm}>
              ✖️
            </button>
            <input
              type="text"
              value={
                editedValues[editingId]?.componentName ||
                objectforediting?.componentName ||
                ""
              }
              onChange={(e) =>
                handleInputChange(editingId, "componentName", e.target.value)
              }
              placeholder="Component Name"
            />
            <input
              type="text"
              value={
                editedValues[editingId]?.componentDescription ||
                objectforediting?.componentDescription ||
                ""
              }
              onChange={(e) =>
                handleInputChange(
                  editingId,
                  "componentDescription",
                  e.target.value
                )
              }
              placeholder="Component Description"
            />
            <input
              type="number"
              value={
                editedValues[editingId]?.numberOfComponents ||
                objectforediting?.numberOfComponents ||
                ""
              }
              onChange={(e) =>
                handleInputChange(
                  editingId,
                  "numberOfComponents",
                  e.target.value
                )
              }
              placeholder="Availability"
            />
            <div>
              <label>Component Category:</label>
              <select
                name="componentCategory"
                onChange={(e) =>
                  handleInputChange(
                    editingId,
                    "componentCategory",
                    e.target.value
                  )
                }
                value={
                  editedValues[editingId]?.componentCategory || ""
                }
              >
                <option value="">Select a category</option>
                <option value="Microcontroller">Microcontroller</option>
                <option value="Microprocessor">Microprocessor</option>
                <option value="Chasis">Chasis</option>
                <option value="Wheels">Wheels</option>
                <option value="Motors">Motors</option>
                <option value="Motor Driver">Motor Driver</option>
              </select>
            </div>
            <input
              type="file"
              onChange={(e) =>
                handleInputChange(
                  editingId,
                  "componentImage",
                  e.target.files[0]
                )
              }
            />
            <button onClick={saveChanges} className="btn-save">
              Save
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AllComponentList;
