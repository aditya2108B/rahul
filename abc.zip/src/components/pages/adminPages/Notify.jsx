import React ,{useEffect}from 'react';
import { useSelector,useDispatch } from 'react-redux';
// Optional: import a date formatting library
// import { format } from 'date-fns';
import { UserListforAdmin } from '../function/Features';
import { addNotification } from '../../redux/counterSlice';

const Notify = () => {
    const notifications = useSelector((state) => state.counter.notifications);

    const dispatch = useDispatch();
    console.log(notifications)

    useEffect(() => {
        if(notifications){
            localStorage.setItem("notifications", JSON.stringify(notifications));
        }else if(localStorage.getItem("notifications")){
            const localNotifications = JSON.parse(localStorage.getItem("notifications"));
            dispatch(addNotification(localNotifications));
        }else{
            UserListforAdmin(dispatch);
        }

    }, [])
    
   
    

  
    if (!notifications || notifications.length === 0) {
        return <div>No notifications available.</div>;
    }

   
   
console.log(notifications)
    return (
        <div>
            {notifications.map((item) => {
                return (
                    <div className="content-section-notify" key={item._id}>
                        <p>{item.history_data}</p>
                        <p className="notification-date-notify">{item.createdAt.slice(0,10)}</p> {/* Optional: use formattedDate here */}
                    </div>
                );
            })}
        </div>
    );
};

export default Notify;
