import React, { useState, useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
import { useDispatch, useSelector } from "react-redux";
import { addNotification } from "../../redux/counterSlice";
import { ReplaceComponents } from "../../redux/counterSlice2";

const UserList = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [users, setUsers] = useState([]);
  const [totalUsers, setTotalUsers] = useState("");
  const [todayUsers, setTodayUsers] = useState("");
  const [totalUsersWithoutLosing, setTotalUsersWithoutLosing] = useState([]);
  const dispatch = useDispatch();
  const components = useSelector((state) => state.components);

  const UserListforAdmin = async () => {
    try {
      const response = await axios.get("http://localhost:8000/allinfo", {
        headers: { Authorization: `Bearer ${Cookies.get("admin")}` },
      });

      const { data } = response;

      setUsers([...data.dataofalluser]);
      setTotalUsersWithoutLosing([...data.dataofalluser]);
      setTodayUsers(data.todayUser);
      setTotalUsers(data.ToalNoofUser);

      dispatch(addNotification(data.notification2));
      dispatch(ReplaceComponents(data.categorisedcomponents));
    } catch (error) {
      console.error("Error fetching data: ", error);
    }
  };

  useEffect(() => {
    UserListforAdmin();
  }, []);

  const search = (term) => {
    const searchedUsers = totalUsersWithoutLosing.filter((user) => {
      const nameExists = user.personalInfo && user.personalInfo[0]?.name;
      const regExists = user.personalInfo && user.personalInfo[0]?.reg;

      return (
        (nameExists &&
          user.personalInfo[0].name
            .toLowerCase()
            .includes(term.toLowerCase())) ||
        (regExists &&
          user.personalInfo[0].reg.toLowerCase().includes(term.toLowerCase()))
      );
    });

    setUsers(searchedUsers);
  };

  const handleMakeAdmin = async (id) => {
    try {
      const response = await axios.post(
        "http://localhost:8000/makeadmin",
        { _id: id },
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );

      if (response.status === 200) {
        UserListforAdmin();
        console.log("User successfully made an admin");
      }
    } catch (error) {
      console.error("Error making user admin:", error.message);
    }
  };

  const removeAdmin = async (id) => {
    try {
      const response = await axios.post(
        "http://localhost:8000/removeadmin",
        { _id: id },
        {
          headers: {
            "Content-Type": "application/json",
          },
          withCredentials: true,
        }
      );

      if (response.status === 200) {
        UserListforAdmin();
        console.log("Admin successfully made a user");
      }
    } catch (error) {
      console.error("Error removing admin:", error.message);
    }
  };

  return (
    <div>
      <div className="content-section">
        <input
          type="text"
          placeholder="Search users..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            search(e.target.value);
          }}
          className="searchBar"
        />
        <h3>New Users Today: {todayUsers}</h3>
        <h3>Total Users: {totalUsers}</h3>
        <ul>
          {users.map((user) => (
            <li key={user._id}>
              {user.personalInfo[0].name} ({user.personalInfo[0].reg})
              {user.role === "user" && (
                <button
                  onClick={() => handleMakeAdmin(user._id)}
                  className="makeAdminBtn"
                >
                  Make Admin
                </button>
              )}
              {user.role === "admin" && (
                <button
                  onClick={() => removeAdmin(user._id)}
                  className="makeAdminBtn"
                >
                  Remove Admin
                </button>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default UserList;
