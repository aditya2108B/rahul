import React, { useRef, useState, useEffect } from "react";
import "../css/Login.css";
import { Link, useNavigate } from "react-router-dom";
import Cmsnav from "./cmsnav";
import Cookies from "js-cookie";

const ForgotPassword = () => {

  const navigate = useNavigate();
  const [errorMessage, setErrorMessage] = useState("");  // State to hold the error message

  

 

  const emailMobile = useRef();
  const [validateData, setValidateData] = useState([]);
  const [firstData, setfirstData] = useState([]);

  

  const handleSubmit = (e) => {
    e.preventDefault();
    const name = checkIfEmailOrMobile(emailMobile.current.value);
    if (name !== "you enter wrong things") {
      setValidateData({
        ...validateData,
        [name]: firstData.emailMobile
      });
    //   forgotPass()
    forgotPass({
        ...validateData,
        [name]: firstData.emailMobile
      })
    } else {
      setErrorMessage("Please enter a valid email or mobile number.");
    }

    emailMobile.current.value = '';
    navigate('/verifyOTP')
  };

  const checkIfEmailOrMobile = (item) => {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobilePattern = /^\d{10}$/;
    if (emailPattern.test(item)) {
      return "email";
    } else if (mobilePattern.test(item)) {
      return "number";
    } else {
      return "you enter wrong things";
    }
  };

  const handleChange = (e) => {
    setfirstData({ ...firstData, [e.target.name]: e.target.value });
  };

  console.log(firstData);

const forgotPass=async(email)=>{try {
    
    const response=await fetch('http://localhost:8000/forgot',{
        method:'POST',
        credentials: "include",
        headers:{
          'Content-Type':'application/json'
        },
        body:JSON.stringify(email)
      })
      const data=await response.json();
      console.log(data)
      
} catch (error) {
    console.log(error)
}

}

  return (
    <>
      <Cmsnav />
      <div className="body">
        <div className="box">
          <div className="container2">
            <div className="top-header">
              <header>Log In</header>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="input-field">
                <input
                  ref={emailMobile}
                  onChange={handleChange}
                  type="text"
                  className="input"
                  name="emailMobile"
                  placeholder=" Email/Mobile Number"
                  autoComplete="email"
                  required
                />
                <i className="fas fa-envelope icon" />
              </div>
              
              

              {/* Display the error message if it exists */}
              {errorMessage && (
                <div className="error-message" style={{ color: 'red', marginBottom: '10px' }}>
                  {errorMessage}
                </div>
              )}

              <div className="input-field input-field2">
                <input type="submit" className="submit" value="check" />
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default ForgotPassword;
