import React, { useRef, useState, useEffect, useCallback } from "react";
import axios from "axios";
import "../css/Profile.css";
import Cmsnav from "./cmsnav";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import { fetchPersonalData, handleSubmit, checkItlogInorNot } from "./function/Features";
import { Oval } from "react-loader-spinner"; // Import loader spinner

const Profile = () => {
  const navigate = useNavigate();
  const [imgurl, setimgurl] = useState("");
  const [personalInfo, setpersonalInfo] = useState({});
  const [loading, setLoading] = useState(true); // Loader state
  const [activeSection, setActiveSection] = useState("history");
  const [editName, setEditName] = useState("");
  const fileInput = useRef();

  useEffect(() => {
    const fetchData = async () => {
      const token = Cookies.get("token");

      if (!token) {
        // No token, navigate to login
        navigate("/login");
        return;
      }

      try {
        checkItlogInorNot("token", navigate);
        await fetchPD(); // Fetch profile data
      } catch (error) {
        console.error("Error fetching data:", error);
        navigate("/login"); // On error, navigate to login
      } finally {
        setLoading(false); // Stop loader
      }
    };

    fetchData();
  }, [navigate]);

  const fetchPD = async () => {
    const object = await fetchPersonalData("token");
    setpersonalInfo({ name: object.name, reg: object.reg });
    setimgurl(object.profileImg);
  };

  const handleClick = () => {
    fileInput.current.click();
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];

    if (file) {
      const token = Cookies.get("token");
      const imgUrl = await handleSubmit(file, token);

      if (imgUrl) {
        setimgurl(imgUrl.profileImg);
      }
    } else {
      console.log("No file selected");
    }
  };

  const handleClearCookie = () => {
    Cookies.remove("token");
    navigate("/login"); // Redirect to login after logout
  };

  const handleSaveProfile = async () => {
    console.log("Saving new name:", editName);
    // Add your logic to update the name on the backend here
    setActiveSection("history");
  };

  if (loading) {
    return (
      <div className="loading-container">
        <Oval height={80} width={80} color="blue" ariaLabel="loading" />
      </div>
    );
  }

  return (
    <>
      <Cmsnav />
      <div className="profile-container">
        <div className="profile-card">
          <div className="profile-header">Profile</div>

          <div
            className="profileImg"
            onClick={handleClick}
            style={{
              backgroundImage: imgurl ? `url(${imgurl})` : "none",
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          >
            <input
              ref={fileInput}
              type="file"
              id="fileInput"
              style={{ display: "none" }}
              accept=".png, .jpg, .jpeg"
              onChange={handleFileChange}
            />
            <div className="plus-icon">+</div>
          </div>

          <div className="profile-info">
            <div className="username">{personalInfo.name || "Username"}</div>
            <div className="email">{personalInfo.reg || "Reg."}</div>
          </div>

          <div className="menu-buttons">
            <button
              className={`menu-button ${
                activeSection === "history" ? "active" : ""
              }`}
              onClick={() => setActiveSection("history")}
            >
              My History
            </button>
            <button
              className={`menu-button ${
                activeSection === "edit" ? "active" : ""
              }`}
              onClick={() => setActiveSection("edit")}
            >
              Edit Profile
            </button>
          </div>

          {activeSection === "history" && (
            <div className="history-table">
              <div className="table-header">
                <div className="table-cell">Component Name</div>
                <div className="table-cell">Issued Date</div>
                <div className="table-cell">Return Date</div>
              </div>
            </div>
          )}

          {activeSection === "edit" && (
            <div className="edit-profile">
              <div className="edit-field">
                <label htmlFor="username">Name: </label>
                <input
                  type="text"
                  id="username"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                />
              </div>

              <button className="save-profile-button" onClick={handleSaveProfile}>
                Save Profile
              </button>
            </div>
          )}

          <button className="logout-button" onClick={handleClearCookie}>
            Logout
          </button>
        </div>
      </div>
    </>
  );
};

export default Profile;
