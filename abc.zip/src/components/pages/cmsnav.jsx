import React, { useState, useRef, useEffect } from "react";
import "../css/cmsnav.css";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Cookies from "js-cookie";

export default function Cmsnav({ bottom }) {
  const searchBar = useRef();
  const navigate = useNavigate();
  const location = useLocation();

  const [checkCookie, setCheckCookie] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // New state to check if the user is admin

  const fetchToken = async () => {
    const token = Cookies.get("token");
    const adminCookie = Cookies.get("admin"); // Checking for admin cookie

    if (token) {
      setCheckCookie(true);
      console.log("Token exists:", token);
    } else {
      console.log("No token found");
    }

    if (adminCookie) {
      setIsAdmin(true); // Set the admin state to true if admin cookie exists
      console.log("Admin cookie found");
    } else {
      console.log("No admin cookie found");
    }
  };

  useEffect(() => {
    fetchToken();
  }, []);

  const [searchData, setSearchData] = useState([]);
  const [componentsOnOrOff, setComponentsOnOrOff] = useState(false);

  useEffect(() => {
    if (location.pathname === "/components") {
      setComponentsOnOrOff(true);
    } else {
      setComponentsOnOrOff(false);
    }
  }, [location.pathname]);

  const handleChange = (e) => {
    setSearchData({ ...searchData, search: e.target.value });
  };

  const handleSearch = () => {
    navigate("/components");
  };

  const aboutClick = () => {
    if (bottom.current) {
      bottom.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <div className="Navbar">
        <div className="left-side">
          <div className="logo">logo</div>
          <div className={"Navigation"}>
            <div className="home">
              <Link to="/">Home</Link>
            </div>
            <div className="more">
              <Link to="/components">Components</Link>
            </div>
            <div className="store" onClick={aboutClick}>
              About
            </div>
          </div>
        </div>
        <div className="right-side">
          <div className="search2">
          
          </div>
          <div className="profile-login">
            <div
              className="signin"
              style={{ display: checkCookie || isAdmin ? "none" : "block" }}
            >
              <Link className="Link" to="/signup">
                Sign In
              </Link>
            </div>
            <div className="profile">
              <Link to={isAdmin ? "/admin" : "/profile"}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  height="2vw"
                  viewBox="0 -960 960 960"
                  width="3.5vw"
                  fill="#ffffff"
                >
                  <path d="M222-255q63-44 125-67.5T480-346q71 0 133.5 23.5T739-255q44-54 62.5-109T820-480q0-145-97.5-242.5T480-820q-145 0-242.5 97.5T140-480q0 61 19 116t63 109Zm257.81-195q-57.81 0-97.31-39.69-39.5-39.68-39.5-97.5 0-57.81 39.69-97.31 39.68-39.5 97.5-39.5 57.81 0 97.31 39.69 39.5 39.68 39.5 97.5 0 57.81-39.69 97.31-39.68 39.5-97.5 39.5Zm.66 370Q398-80 325-111.5t-127.5-86q-54.5-54.5-86-127.27Q80-397.53 80-480.27 80-563 111.5-635.5q31.5-72.5 86-127t127.27-86q72.76-31.5 155.5-31.5 82.73 0 155.23 31.5 72.5 31.5 127 86t86 127.03q31.5 72.53 31.5 155T848.5-325q-31.5 73-86 127.5t-127.03 86Q562.94-80 480.47-80Zm-.47-60q55 0 107.5-16T691-212q-51-36-104-55t-107-19q-54 0-107 19t-104 55q51 40 103.5 56T480-140Zm0-370q34 0 55.5-21.5T557-587q0-34-21.5-55.5T480-664q-34 0-55.5 21.5T403-587q0 34 21.5 55.5T480-510Zm0-77Zm0 374Z" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </div>
      <div className="Navbar2">
        <div className="upper">
          <div className="logoRes">Logo</div>
          <div className="menu" onClick={aboutClick}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              height="48px"
              viewBox="0 -960 960 960"
              width="48px"
              fill="#ffffff"
            >
              <path d="M120-240v-60h720v60H120Zm0-210v-60h720v60H120Zm0-210v-60h720v60H120Z" />
            </svg>
          </div>
        </div>
       
      </div>
    </>
  );
}
