import React, { useEffect, useRef, useState } from 'react';
import '../css/Signup.css';
import { Link } from 'react-router-dom';
import Cmsnav from './cmsnav';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

const Signup = () => {
  const navigate = useNavigate();
  const fetchToken = async () => {
    const token = Cookies.get("token");
    if (token) {
      setTimeout(() => {
        navigate('/');

      },3000)
      console.log("Token exists:", token);
    } else {
      console.log("No token found");
    }
  };

  useEffect(() => {
    fetchToken();
  }, []);
  
  const email = useRef();
  const mobile = useRef();
  const password = useRef();
  const confirmPass = useRef();
  const username = useRef(); // New ref for username
  const regNo = useRef(); // New ref for registration number

  const [data, setData] = useState({});

  const sendData = () => {
    fetch('http://localhost:8000/signup', {
      method: 'POST',
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((data) => {
        fetchToken();
        console.log('Success:', data);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  };

  const handleChange = (e) => {
    if (e.target.name !== 'confirmPass') {
      setData({ ...data, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (password.current.value === confirmPass.current.value) {
      sendData();
      email.current.value = "";
      mobile.current.value = "";
      password.current.value = "";
      confirmPass.current.value = "";
      username.current.value = ""; // Clear username
      regNo.current.value = ""; // Clear registration number
    } else {
      alert('Password and confirm password are not the same');
    }
  };

  return (
    <>
      <Cmsnav />
      <div className="body">
        <div className="box">
          <div className="container">
            <div className="top-header">
              <header>Create Account</header>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="input-field">
                <input
                  type="text"
                  name="username"
                  className="input"
                  placeholder="  Username"
                  required
                  ref={username} // Reference for username
                  onChange={handleChange}
                  autoComplete="username"
                />
                <i className="fas fa-user icon" />
              </div>
              <div className="input-field">
                <input
                  type="text"
                  name="registrationNumber"
                  className="input"
                  placeholder="  Registration Number"
                  required
                  ref={regNo} // Reference for registration number
                  onChange={handleChange}
                  autoComplete="off"
                />
                <i className="fas fa-id-card icon" />
              </div>
              <div className="input-field">
                <input
                  type="email"
                  name="email"
                  className="input"
                  placeholder="  Email"
                  required
                  ref={email}
                  onChange={handleChange}
                  autoComplete="email"
                />
                <i className="fas fa-envelope icon" />
              </div>
              <div className="input-field">
                <input
                  ref={mobile}
                  name="number"
                  type="tel"
                  pattern="\d{10}"  
                  className="input"
                  placeholder="  Mobile Number"
                  required
                  onChange={handleChange}
                  autoComplete="tel"
                />
                <i className="fas fa-phone icon" />
              </div>
              <div className="input-field">
                <input
                  ref={password}
                  name="password"
                  type="password"
                  className="input"
                  placeholder="  Password"
                  required
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <i className="fas fa-lock icon" />
              </div>
              <div className="input-field">
                <input
                  ref={confirmPass}
                  name="confirmPass"
                  type="password"
                  className="input"
                  placeholder="  Confirm Password"
                  required
                  onChange={handleChange}
                  autoComplete="new-password"
                />
                <i className="fas fa-lock icon" />
              </div>
              <div className="terms-conditions">
                <input type="checkbox" id="terms" required />
                <label htmlFor="terms">
                  I accept the <a href="terms.html">Terms and Conditions</a>
                </label>
              </div>
              <div className="input-field input-field2">
                <input type="submit" className="submit" value="Create Account" />
                <div className="login-link">
                  <p>
                    Already have an account?<Link to="/login">Login</Link>
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Signup;
