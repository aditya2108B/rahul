import React from "react";
import "../css/footer.css";

const Footer = () => {
  return (
    <div>
      <div className="footer">
        <div className="headings">
          <div className="cms">CMS</div>
          <div className="cmsContent">
            The Component Management System simplifies the process of
            organizing, tracking and deploying the components{" "}
          </div>
        </div>
        <div className="content">
          <div className="quick">Quick Links</div>
          <div className="quickContent">
            <div className="qone">About</div>
            <div className="qtwo">Components</div>
            <div className="qthree">Privacy</div>
            <div className="qfour">Terms & Conditions</div>
          </div>
        </div>
        <div className="contactDiv">
          <div className="contact">Contact</div>
          <div className="contactContent">
            <div className="email">cms@sggs.ac.in</div>
            <div className="logo">
              <div className="logo1">
                <a href="https://www.youtube.com/@rnxgsggs2574" target="_blank">
                  <i className="fa fa-youtube-play"></i>
                </a>
              </div>
              <div className="logo2">
                {" "}
                <a href="https://www.instagram.com/team_rnxg/" target="_blank">
                  <i className="fa fa-instagram"></i>
                </a>
              </div>
              <div className="logo3">
                <a
                  href="https://www.linkedin.com/company/rnxg/about/"
                  target="_blank"
                >
                  <i className="fa fa-linkedin"></i>
                </a>
              </div>
              <div className="logo4">
                <a href="https://www.facebook.com/rnxgsggs/" target="_blank">
                  <i className="fa fa-facebook"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="copyRight">
        <div className="text">
          © 2024, RNXG . All Rights Reserved.
        </div>
      </div>
    </div>
  );
};

export default Footer;
