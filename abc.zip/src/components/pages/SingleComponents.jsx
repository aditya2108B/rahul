import React, { useEffect, useState, useRef } from "react";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import "../css/SingleComponents.css";
import axios from "axios";
import Cmsnav from "./cmsnav";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";
import ReqSendSuccess from "./issueReq/ReqSendSuccess";
import ReqSendUnsuccess from "./issueReq/ReqSendUnsucces";
import LimitNotDefined from "./issueReq/LimitNotDefined";
import { Oval } from "react-loader-spinner";

const SingleComponents = () => {
  const [component, setComponent] = useState(null);
  const [loading, setLoading] = useState(true); // State for managing loader
  const components = useSelector((state) => state.components);
  const [recommend, setRecommend] = useState([]);
  const { id } = useParams();
  const navigate = useNavigate();
  const [pageChanging, setPageChanging] = useState(false);
  const [issueSuccess, setIssueSuccess] = useState(false);
  const [issueUnsuccess, setIssueUnsuccess] = useState(false);
  const quantity = useRef(null);
  const [limitExceed, setLimitExceed] = useState(false);

  // Fetch component and recommendations
  const fetchCompo = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `http://localhost:8000/components/${id}`
      );
      const singleComponent = response.data;
      setComponent(singleComponent.components[0]);
      setRecommend(singleComponent.allRecommendedCompo);
      localStorage.setItem(
        "recommend",
        JSON.stringify(singleComponent.allRecommendedCompo)
      );
      localStorage.setItem(
        "singleComponent",
        JSON.stringify(singleComponent.components[0])
      );
    } catch (error) {
      console.error("Error fetching component data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (components?.AllComponents) {
      const singleComponent = components.AllComponents.find(
        (item) => item._id === id
      );
      if (singleComponent) {
        setComponent(singleComponent);
        const recommendComponents = components.AllComponents.filter(
          (item) =>
            item.componentCategory === singleComponent.componentCategory &&
            item._id !== singleComponent._id
        );
        setRecommend(recommendComponents);
      } else {
        fetchCompo();
      }
    } else {
      fetchCompo();
    }
  }, [id, components, pageChanging]);

  const handleIssue = async () => {
    const token = Cookies.get("token");
    const admin = Cookies.get("admin");
    if (!token && !admin) {
      navigate(`/login?redirect=/components/${id}`);
      return;
    }

    if (
      0 < Number(quantity.current.value) &&
      Number(quantity.current.value) < component.numberOfComponents
    ) {
      try {
        const response = await axios.post(
          `http://localhost:8000/issueReq`,
          { id: id, quantity: quantity.current.value },
          {
            headers: { "Content-Type": "application/json" },
            withCredentials: true,
          }
        );
        if (response.status === 200) {
          setIssueSuccess(true);
        } else {
          setIssueUnsuccess(true);
        }
      } catch (error) {
        console.error("Error issuing component:", error);
        setIssueUnsuccess(true);
      }
    } else {
      setLimitExceed(true);
    }
  };

  if (loading) {
    return<div>
    <Oval
      height={80}
      width={80}
      color="blue"
      ariaLabel="loading"
    />
  </div>
  }

  if (!component) {
    return <div>Component not found.</div>;
  }

  const {
    componentName,
    componentCategory,
    componentImage,
    numberOfComponents,
    componentDescription,
  } = component;

  return (
    <>
      <Cmsnav />
      {issueSuccess || issueUnsuccess || limitExceed ? (
        issueUnsuccess || limitExceed ? (
          issueUnsuccess ? (
            <ReqSendUnsuccess />
          ) : (
            <LimitNotDefined />
          )
        ) : (
          <ReqSendSuccess />
        )
      ) : (
        <div className="component-container2">
          <div className="left-section">
            <img src={componentImage} alt={componentName} />
          </div>
          <div className="right-section">
            <h2>{componentName}</h2>
            <p>
              <strong>Category:</strong> {componentCategory}
            </p>
            <div className="component-description">{componentDescription}</div>
            <p>
              <strong>Quantity:</strong> {numberOfComponents}
            </p>
          </div>
          <div className="formForCompo">
            <form>
              <input
                type="number"
                min={1}
                max={numberOfComponents}
                ref={quantity}
                defaultValue={1}
              />
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleIssue();
                }}
              >
                Issue
              </button>
              <button>Add to cart</button>
            </form>
          </div>
        </div>
      )}
      <div className="recommend-flex">
        {recommend.length > 0 ? (
          recommend.map((item) => (
            <div key={item._id} className="component-card2">
              <div className="component-content">
                {item.componentImage && (
                  <img
                    src={item.componentImage}
                    alt={item.componentName}
                    className="component-image"
                  />
                )}
                <div className="component-title">{item.componentName}</div>
                <div className="component-availability">
                  Availability: {item.numberOfComponents}
                </div>
                <button
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(`/components/${item._id}`);
                    setPageChanging(!pageChanging);
                  }}
                >
                  Issue
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="no-results">No components found</div>
        )}
      </div>
    </>
  );
};

export default SingleComponents;
