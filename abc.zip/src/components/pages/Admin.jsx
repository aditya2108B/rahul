import React, { useState, useEffect } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import Cmsnav from "./cmsnav";
import Cookies from "js-cookie";
import { useDispatch, useSelector } from "react-redux";
import { clearNotifications } from "../redux/counterSlice";
import { fetchPersonalData, checkItlogInorNot } from "./function/Features";
import "../css/Admin.css";
import { replacepersonalData } from "../redux/personalData";


const AdminLayout = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Select the personal data from the Redux store
  const selector = useSelector((state) => state.personalData);
  const [profileImg, setProfileImg] = useState(null); // Start with null and update with selector data

  // Handle logout and cookie removal
  const handleLogout = async () => {
    await Cookies.remove("admin");
    dispatch(clearNotifications());
    checkItlogInorNot("admin", navigate);
  };

  // Synchronize profile image with Redux store data and handle side effects
  useEffect(() => {
    // Fetch personal data and update the Redux store
    fetchPersonalData("admin").then((data) => {
      dispatch(replacepersonalData(data));
    });

    // Check login status
    checkItlogInorNot("admin", navigate);
  }, [dispatch, navigate]);

  // Update local profile image state when Redux store updates
  useEffect(() => {
    if (selector && selector.personalData) {
      setProfileImg(selector.personalData); 
    }
  }, [selector]);

  return (
    <>
      <Cmsnav />
      <div className="adminPage">
        <div className="menuForAdmin">
          <div className="profile-section">
            <div className="profile-picture" onClick={() => document.getElementById("profileImg").click()}>
              {profileImg && profileImg.profileImg ? (
                <img src={profileImg.profileImg} alt="Profile" />
              ) : (
                <span>Profile Image</span>
              )}
            </div>
            <div className="admin-name-section">
              <p className="admin-name">
                {profileImg && profileImg.name ? profileImg.name : "Username"}
              </p>
            </div>
          </div>

          {/* Menu options */}
          <div className="menu-options">
            <NavLink to="users" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Users</button>
            </NavLink>
            <NavLink to="issue-requests" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Issue Requests</button>
            </NavLink>
            <NavLink to="notify" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Notification</button>
            </NavLink>
            <NavLink to="chart" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Analysis</button>
            </NavLink>
            <NavLink to="components" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Components</button>
            </NavLink>
            <NavLink to="add-components" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Add Components</button>
            </NavLink>
            <NavLink to="edit" className={({ isActive }) => (isActive ? "active" : "")}>
              <button>Edit</button>
            </NavLink>
          </div>

          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </div>

        <div className="contentForAdmin">
          <Outlet />
        </div>
      </div>
    </>
  );
};

export default AdminLayout;
