import React, { useState, useEffect } from "react";
import "../css/cards.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { NavLink } from "react-router-dom";

const Cards = () => {
  const [boxes, setBoxes] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchComponents = async () => {
      try {
        const response = await axios.get("http://localhost:8000/getcomponents", {
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (Array.isArray(response.data) && Array.isArray(response.data[0])) {
          const allComponents = response.data[0].flatMap((item) => item);
          const limitedComponents = allComponents.slice(0, 7);
          setBoxes(limitedComponents);
        } else {
          console.error("Unexpected response format:", response.data);
        }

       
      } catch (error) {
       
      }
    };

    fetchComponents();
  },[]);

 

  return (
    <div className="categoriesCard">
      {boxes.map((item, index) => (
        <div key={index} className="component-card2">
          <div className="component-content">
            {item.componentImage && (
              <img
                src={item.componentImage}
                alt={item.componentName || "Component"}
                className="component-image"
              />
            )}
            <div className="component-title">
              {item.componentName || "Component"}
            </div>
            <div className="component-availability">
              Availability: {item.numberOfComponents || "0"}
            </div>
            <button
              onClick={(e) => {
                e.preventDefault();
                navigate(`/components/${item._id}`);
              }}
              className="issue-btn"
            >
              Issue
            </button>
          </div>
        </div>
      ))}
      <NavLink to={"/components"} className="more-word">
        More.....
      </NavLink>
    </div>
  );
};

export default Cards;
