import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { Provider } from 'react-redux';
import { store } from './components/redux/Store';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

// Import pages
import Hero from './components/pages/Hero';
import Login from './components/pages/Login';
import Signup from './components/pages/Signup';
import ForgotPassword from './components/pages/ForgotPassword';
import VerifyOTP from './components/pages/VerifyOTP';
import ResetPass from './components/pages/ResetPass';
import AdminLayout from './components/pages/Admin';
import UserList from './components/pages/adminPages/UserList';
import IssueReq from './components/pages/adminPages/IssueReq';
import Notify from './components/pages/adminPages/Notify';
import AllComponentList from './components/pages/adminPages/AllComponentList';
import AddComponents from './components/pages/adminPages/AddComponents';
import EditPage from './components/pages/adminPages/EditPage';
import BarChart from './components/pages/adminPages/Chart';
import AfterSearchPage from './components/pages/AfterSearcgPage.jsx'
import Profile from './components/pages/Profile.jsx'
import SingleComponents from './components/pages/SingleComponents.jsx'




const router = createBrowserRouter([
  {
    path: "/",
    element: <Hero />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/signup",
    element: <Signup />,
  },
  {
    path: "/forgotpass",
    element: <ForgotPassword />,
  },
  {
    path: "/verifyotp",
    element: <VerifyOTP />,
  },
  {
    path: "/resetpass",
    element: <ResetPass />,
  },
  {
    path: "/components",
    element: <AfterSearchPage />,
  },
  {
    path: "/profile",
    element: <Profile />,
  },
  {
    path:"/components/:id",
    element:<SingleComponents />
  },
  
  {
    path: "/admin",
    element: <AdminLayout />,
    children: [
      { path: "users", element: <UserList /> },
      { path: "issue-requests", element: <IssueReq /> },
      { path: "notify", element: <Notify /> },
      { path: "chart", element: <BarChart /> },
      { path: "components", element: <AllComponentList /> },
      { path: "add-components", element: <AddComponents /> },
      { path: "edit", element: <EditPage /> },
    ],
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <RouterProvider router={router} />
    </Provider>
  </React.StrictMode>,
);
